阿里巴巴开放云搜索（Alibaba OpenSearch）是为广大站长，APP开发者量身定制打造的针对结构化数据的云端搜索服务。您可以通过我们提供的平台非常容易的拥有高质量，易扩展，可定制的搜索服务而不用关心搜索的各种技术细节。

更多的sdk用法和接口参考可查看wiki：http://wiki.opensearch.etao.com/index.php?title=SDK